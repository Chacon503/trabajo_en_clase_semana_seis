#include "symbols.h"
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
SymbolEntry* root_table= NULL;

SymbolEntry* create_entry(char* name){
    //Asignar en memoria el nodo
    SymbolEntry *node =  (SymbolEntry*) malloc(sizeof(SymbolEntry));

    node->data_type = TYPE_INT;
    node->i_value = 0;
    node->identifier = strdup(name);

    printf("Entry created: %s",name);

    return node;
}
