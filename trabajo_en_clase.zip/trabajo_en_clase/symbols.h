#ifndef SYMBOLS_H
#define SYMBOLS_H

typedef  enum {
    TYPE_INT
} DataType;

typedef struct SymbolEntry {
   DataType data_type;
   int i_value;
   char* identifier;
} SymbolEntry;

//Prototipos
SymbolEntry* create_entry(char *name);


#endif // SYMBOLS_H
