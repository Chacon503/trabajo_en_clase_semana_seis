%{
#include <stdio.h>
#include "symbols.h"
int yylex();
void yyerror(const char *s);
extern FILE *yyin;

%}

/*Define the yylval structure*/
%union {
    int i_val;
    int n_val;
    int type_enum;
    struct SymbolEntry *entry;
}

%token VAR
%token INT_TYPE
%token  COLON SEMICOLON LBRACKET RBRACKET ASSIGN

/*Type definitions for TOKEN*/
%token <entry> IDENTIFIER
%token <i_val> INT_LITERAL
%token <n_val> NUMBER

/*Defining types into the parser*/
%type <type_enum> data_type
%type <n_val> expression

%%
program:
        program statement
        | /**/
        ;
statement:  variable_definition SEMICOLON;

data_type:
       INT_TYPE  { $$=TYPE_INT; }
       ;
expression:
    NUMBER      { $$ = $1; }
    | INT_LITERAL { $$= (int) $1; }
    ;

variable_definition: VAR COLON LBRACKET data_type RBRACKET IDENTIFIER ASSIGN expression {
    $6->data_type =(DataType) $4;
    printf("ASSIGN Value> ID:%s  TYPE: %i VALUE:%d", $6->identifier, $4, $8);
    switch($4){
        case TYPE_INT: $6->i_value =(int)$8;
    }
}
;

%%

/* Error handler */
void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}

/*Main  Function*/
int main(int argc, char **argv) {
    if (argc > 1) {
        FILE *file = fopen(argv[1], "r");
        if (!file) {
            fprintf(stderr, "Could not open %s\n", argv[1]);
            return 1;
        }
        extern FILE *yyin;
        yyin = file;
    }

    int result = yyparse();

    if (result == 0) {
        printf("Parse Successful!\n");
    }

    return result;
}
